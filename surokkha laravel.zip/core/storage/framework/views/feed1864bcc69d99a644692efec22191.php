<?php $__env->startSection('content'); ?>
    <div class="container-fluid px-4">
        <h3 class="mt-4 mb-0">Control Panel</h3>
        <ol class="breadcrumb mb-3">
            <li class="breadcrumb-item active">Home / Control Panel</li>
        </ol>
        <div class="row">
            <div class="col-6">
                <div class="card mb-3 border border-2 border-success bg-white shadow">
                    <div class="card-header">
                        <h5 class="mb-0 text-success">
                            <i class="fa-solid fa-hand-holding-heart"></i> Minimum Recharge Limit
                        </h5>
                    </div>
                    <div class="card-body">
                        <div class="input-group mb-3">
                            <input type="text" class="form-control" placeholder="enter min recharge limit">
                            <span class="input-group-text" id="basic-addon2">Taka</span>
                        </div>
                        <button class="btn btn-success w-100" type="submit">Submit</button>
                    </div>
                </div>
            </div>
            <div class="col-6">
                <div class="card mb-3 border border-2 border-success bg-white shadow">
                    <div class="card-header">
                        <h5 class="mb-0 text-success">
                            <i class="fa-solid fa-credit-card"></i> Charge for every Card
                        </h5>
                    </div>
                    <div class="card-body">
                        <div class="input-group mb-3">
                            <input type="text" class="form-control" placeholder="enter min recharge limit">
                            <span class="input-group-text" id="basic-addon2">Taka</span>
                        </div>
                        <button class="btn btn-success w-100" type="submit">Submit</button>
                    </div>
                </div>
            </div>

            <div class="col-12">
                <div class="card mb-3 border border-2 border-success bg-white shadow">
                    <div class="card-header">
                        <h5 class="mb-0 text-success">
                            <i class="fa-solid fa-headset"></i> Customer Support Link
                        </h5>
                    </div>
                    <div class="card-body">
                        <div class="input-group mb-3">
                            <input type="text" class="form-control" placeholder="enter your telegram or whatsapp link">
                        </div>
                        <button class="btn btn-success w-100" type="submit">Submit</button>
                    </div>
                </div>
            </div>

            <div class="col-6">
                <div class="card mb-3 border border-2 border-success bg-white shadow">
                    <div class="card-header">
                        <h5 class="mb-0 text-success">
                            <i class="fa-solid fa-comments-dollar"></i> Recharge Notice
                        </h5>
                    </div>
                    <div class="card-body">
                        <div class="input-group mb-3">
                            <textarea name="recharge_notice" class="form-control" id="" cols="30" rows="5"></textarea>
                        </div>
                        <button class="btn btn-success w-100" type="submit">Submit</button>
                    </div>
                </div>
            </div>
            <div class="col-6">
                <div class="card mb-3 border border-2 border-success bg-white shadow">
                    <div class="card-header">
                        <h5 class="mb-0 text-success">
                            <i class="fa-solid fa-triangle-exclamation"></i> Site Notice
                        </h5>
                    </div>
                    <div class="card-body">
                        <div class="input-group mb-3">
                            <textarea name="site_notice" class="form-control" id="" cols="30" rows="5"></textarea>
                        </div>
                        <button class="btn btn-success w-100" type="submit">Submit</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/mrorko/Sites/surokkha-laravel/core/resources/views/admin/controll.blade.php ENDPATH**/ ?>