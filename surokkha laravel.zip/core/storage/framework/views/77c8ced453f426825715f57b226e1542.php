<?php $__env->startSection('content'); ?>
    <div class="container-fluid px-4">
        <h3 class="mt-4 mb-0">Submission List</h3>
        <ol class="breadcrumb mb-3">
            <li class="breadcrumb-item active">Home / Submission List</li>
        </ol>
        <div class="row">
            <div class="col-12 mb-3">
                <marquee class="p-3 bg-white rounded border border-2 border-warning">
                    <?php echo e(@$control->site_notice); ?>

                </marquee>
            </div>
            <div class="col-12">
                <div class="card mb-4 border border-2 border-warning bg-white shadow">
                    <div class="card-header">
                        <i class="fas fa-table me-1"></i>
                        My Submission List
                    </div>
                    <div class="card-body">
                        <table id="datatablesSimple">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Name</th>
                                    <th>Date of Birth</th>
                                    <th>Nationality</th>
                                    <th>Gender</th>
                                    
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tfoot>
                                <tr>
                                    <th>#</th>
                                    <th>Name</th>
                                    <th>Date of Birth</th>
                                    <th>Nationality</th>
                                    <th>Gender</th>
                                    
                                    <th>Action</th>
                                </tr>
                            </tfoot>
                            <tbody>
                                <tr>
                                    <td>1</td>
                                    <td>TAEBA AKTER SWEETY</td>
                                    <td>28/10/2002</td>
                                    <td>Bangladeshi</td>
                                    <td>Female</td>
                                    
                                    <td>
                                        <a class="btn btn-sm btn-success rounded-circle" href="#"><i
                                                class="fa-solid fa-pen-to-square"></i></a>
                                        <a class="btn btn-sm btn-danger rounded-circle" href="#"><i
                                                class="fa-solid fa-trash"></i></a>
                                        <a class="btn btn-sm btn-info rounded-circle" href="#"><i
                                                class="fa-solid fa-download"></i></a>
                                    </td>
                                </tr>
                                <tr>
                                    <td>2</td>
                                    <td>Hemel</td>
                                    <td>28/10/2002</td>
                                    <td>Bangladeshi</td>
                                    <td>Male</td>
                                    
                                    <td>
                                        <a class="btn btn-sm btn-success rounded-circle" href="#"><i
                                                class="fa-solid fa-pen-to-square"></i></a>
                                        <a class="btn btn-sm btn-danger rounded-circle" href="#"><i
                                                class="fa-solid fa-trash"></i></a>
                                        <a class="btn btn-sm btn-info rounded-circle" href="#"><i
                                                class="fa-solid fa-download"></i></a>
                                    </td>
                                </tr>
                                <tr>
                                    <td>3</td>
                                    <td>Sakib</td>
                                    <td>28/10/2002</td>
                                    <td>Bangladeshi</td>
                                    <td>Male</td>
                                    
                                    <td>
                                        <a class="btn btn-sm btn-success rounded-circle" href="#"><i
                                                class="fa-solid fa-pen-to-square"></i></a>
                                        <a class="btn btn-sm btn-danger rounded-circle" href="#"><i
                                                class="fa-solid fa-trash"></i></a>
                                        <a class="btn btn-sm btn-info rounded-circle" href="#"><i
                                                class="fa-solid fa-download"></i></a>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/mrorko/Sites/surokkha-laravel/core/resources/views/dashboard.blade.php ENDPATH**/ ?>